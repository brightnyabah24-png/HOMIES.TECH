import nodemailer from "nodemailer";

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env["EMAIL_USER"] ?? "Brightnyaba@gmail.com",
    pass: process.env["EMAIL_PASS"] ?? "",
  },
});

const ADMIN_EMAIL = process.env["EMAIL_USER"] ?? "Brightnyaba@gmail.com";
const ADMIN_WHATSAPP = "233552929516";

export async function sendBookingNotificationToAdmin(booking: {
  fullName: string;
  phone: string;
  email?: string | null;
  deviceType: string;
  brand: string;
  problemDescription: string;
  preferredDate: string;
  preferredTime?: string | null;
  serviceType: string;
  trackingId: string;
}): Promise<void> {
  try {
    await transporter.sendMail({
      from: ADMIN_EMAIL,
      to: ADMIN_EMAIL,
      subject: `New Repair Booking - ${booking.trackingId}`,
      html: `
        <h2>New Repair Booking Received</h2>
        <p><strong>Tracking ID:</strong> ${booking.trackingId}</p>
        <p><strong>Customer:</strong> ${booking.fullName}</p>
        <p><strong>Phone:</strong> ${booking.phone}</p>
        <p><strong>Email:</strong> ${booking.email ?? "Not provided"}</p>
        <p><strong>Device:</strong> ${booking.brand} ${booking.deviceType}</p>
        <p><strong>Problem:</strong> ${booking.problemDescription}</p>
        <p><strong>Preferred Date:</strong> ${booking.preferredDate} ${booking.preferredTime ?? ""}</p>
        <p><strong>Service Type:</strong> ${booking.serviceType}</p>
      `,
    });
  } catch (err) {
    console.error("Failed to send admin booking email:", err);
  }
}

export async function sendBookingConfirmationToCustomer(booking: {
  fullName: string;
  phone: string;
  email: string;
  trackingId: string;
  deviceType: string;
  brand: string;
  preferredDate: string;
}): Promise<void> {
  if (!booking.email) return;
  try {
    await transporter.sendMail({
      from: ADMIN_EMAIL,
      to: booking.email,
      subject: `Booking Confirmed - Tracking ID: ${booking.trackingId}`,
      html: `
        <h2>Your Repair Booking is Confirmed!</h2>
        <p>Dear ${booking.fullName},</p>
        <p>Your booking has been received. Use the tracking ID below to check your repair status.</p>
        <h3>Tracking ID: <strong>${booking.trackingId}</strong></h3>
        <p><strong>Device:</strong> ${booking.brand} ${booking.deviceType}</p>
        <p><strong>Preferred Date:</strong> ${booking.preferredDate}</p>
        <p>Track your device at: https://homiestech.com/tracking</p>
        <br/>
        <p>Thank you for choosing Homies Tech!</p>
        <p>Call us: 0256992268 | WhatsApp: 0552929516</p>
      `,
    });
  } catch (err) {
    console.error("Failed to send customer confirmation email:", err);
  }
}

export async function sendRepairReadyNotification(booking: {
  fullName: string;
  phone: string;
  email?: string | null;
  trackingId: string;
}): Promise<void> {
  // Email notification
  if (booking.email) {
    try {
      await transporter.sendMail({
        from: ADMIN_EMAIL,
        to: booking.email,
        subject: `Your Repair is Ready - ${booking.trackingId}`,
        html: `
          <h2>Your Device Repair is Complete!</h2>
          <p>Dear ${booking.fullName},</p>
          <p>Great news! Your device repair has been completed.</p>
          <p><strong>Tracking ID:</strong> ${booking.trackingId}</p>
          <p>Please visit our shop to collect your device.</p>
          <p>Call us to arrange pickup: 0256992268</p>
          <br/>
          <p>Thank you for choosing Homies Tech!</p>
        `,
      });
    } catch (err) {
      console.error("Failed to send repair ready email:", err);
    }
  }
}

export async function sendContactFormEmail(contact: {
  name: string;
  phone: string;
  email?: string;
  message: string;
}): Promise<void> {
  try {
    await transporter.sendMail({
      from: ADMIN_EMAIL,
      to: ADMIN_EMAIL,
      subject: `New Contact Form Message from ${contact.name}`,
      html: `
        <h2>New Contact Form Submission</h2>
        <p><strong>Name:</strong> ${contact.name}</p>
        <p><strong>Phone:</strong> ${contact.phone}</p>
        <p><strong>Email:</strong> ${contact.email ?? "Not provided"}</p>
        <p><strong>Message:</strong></p>
        <p>${contact.message}</p>
      `,
    });
  } catch (err) {
    console.error("Failed to send contact form email:", err);
  }
}

export function buildWhatsAppBookingMessage(booking: {
  fullName: string;
  phone: string;
  deviceType: string;
  brand: string;
  problemDescription: string;
  preferredDate: string;
  serviceType: string;
  trackingId: string;
}): string {
  return `New Booking Alert!\nTracking: ${booking.trackingId}\nCustomer: ${booking.fullName}\nPhone: ${booking.phone}\nDevice: ${booking.brand} ${booking.deviceType}\nProblem: ${booking.problemDescription}\nDate: ${booking.preferredDate}\nService: ${booking.serviceType}`;
}

export const WHATSAPP_NUMBER = ADMIN_WHATSAPP;
