import { Router } from "express";
import { db } from "@workspace/db";
import { bookingsTable, productsTable, reviewsTable, paymentsTable } from "@workspace/db";
import { eq, gte, desc, and, sql } from "drizzle-orm";
import { requireAuth } from "../lib/auth";

const router = Router();

router.get("/dashboard/stats", requireAuth, async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const [totalBookings] = await db.select({ count: sql<number>`count(*)::int` }).from(bookingsTable);
    const [todayBookings] = await db.select({ count: sql<number>`count(*)::int` }).from(bookingsTable).where(gte(bookingsTable.createdAt, today));
    const [totalProducts] = await db.select({ count: sql<number>`count(*)::int` }).from(productsTable);
    const [totalReviews] = await db.select({ count: sql<number>`count(*)::int` }).from(reviewsTable);
    const [pendingReviews] = await db.select({ count: sql<number>`count(*)::int` }).from(reviewsTable).where(eq(reviewsTable.status, "pending"));
    const [pendingBookings] = await db.select({ count: sql<number>`count(*)::int` }).from(bookingsTable).where(eq(bookingsTable.status, "pending"));
    const [revenueRow] = await db.select({ total: sql<number>`coalesce(sum(amount::numeric), 0)::float` }).from(paymentsTable).where(eq(paymentsTable.status, "success"));

    res.json({
      totalBookings: totalBookings?.count ?? 0,
      todayBookings: todayBookings?.count ?? 0,
      totalProducts: totalProducts?.count ?? 0,
      totalReviews: totalReviews?.count ?? 0,
      pendingReviews: pendingReviews?.count ?? 0,
      pendingBookings: pendingBookings?.count ?? 0,
      estimatedRevenue: revenueRow?.total ?? 0,
      totalPayments: revenueRow?.total ?? 0,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch stats" });
  }
});

router.get("/dashboard/bookings-chart", requireAuth, async (req, res) => {
  try {
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 6);
    sevenDaysAgo.setHours(0, 0, 0, 0);

    const rows = await db.select({
      date: sql<string>`date_trunc('day', created_at)::date::text`,
      count: sql<number>`count(*)::int`,
    })
      .from(bookingsTable)
      .where(gte(bookingsTable.createdAt, sevenDaysAgo))
      .groupBy(sql`date_trunc('day', created_at)`)
      .orderBy(sql`date_trunc('day', created_at)`);

    // Fill missing days
    const result: Array<{ date: string; count: number }> = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split("T")[0]!;
      const found = rows.find((r) => r.date === dateStr);
      result.push({ date: dateStr, count: found?.count ?? 0 });
    }
    res.json(result);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch chart data" });
  }
});

router.get("/dashboard/recent-bookings", requireAuth, async (req, res) => {
  try {
    const rows = await db.select().from(bookingsTable).orderBy(desc(bookingsTable.createdAt)).limit(10);
    res.json(rows.map((b) => ({
      id: b.id,
      fullName: b.fullName,
      phone: b.phone,
      email: b.email,
      deviceType: b.deviceType,
      brand: b.brand,
      problemDescription: b.problemDescription,
      preferredDate: b.preferredDate,
      preferredTime: b.preferredTime,
      serviceType: b.serviceType,
      status: b.status,
      trackingId: b.trackingId,
      depositPaid: b.depositPaid,
      depositAmount: b.depositAmount != null ? Number(b.depositAmount) : null,
      technicianNotes: b.technicianNotes,
      createdAt: b.createdAt.toISOString(),
    })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch recent bookings" });
  }
});

export default router;
