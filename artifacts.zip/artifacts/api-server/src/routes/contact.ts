import { Router } from "express";
import { sendContactFormEmail } from "../lib/notifications";

const router = Router();

router.post("/contact", async (req, res) => {
  try {
    const { name, phone, email, message } = req.body;
    if (!name || !phone || !message) {
      res.status(400).json({ error: "name, phone, message required" });
      return;
    }
    await sendContactFormEmail({ name, phone, email, message });
    res.json({ message: "Message sent successfully" });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to send message" });
  }
});

export default router;
