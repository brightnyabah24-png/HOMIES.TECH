import { Router } from "express";
import { db } from "@workspace/db";
import { paymentsTable } from "@workspace/db";
import { eq, and, desc, sql } from "drizzle-orm";
import { requireAuth } from "../lib/auth";
import axios from "axios";

const router = Router();

const PAYSTACK_SECRET = process.env["PAYSTACK_SECRET_KEY"] ?? "";
const paystackHeaders = () => ({ Authorization: `Bearer ${PAYSTACK_SECRET}`, "Content-Type": "application/json" });

router.post("/payments/initialize", async (req, res) => {
  try {
    const { amount, email, phone, network, bookingId, purpose } = req.body;
    if (!amount || !email || !phone || !network) {
      res.status(400).json({ error: "amount, email, phone, network required" });
      return;
    }

    const reference = `HT-${Date.now()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
    const amountInKobo = Math.round(amount * 100);

    let paystackRes: { data: { authorization_url: string; reference: string; access_code: string } } | null = null;

    if (PAYSTACK_SECRET) {
      try {
        const { data } = await axios.post<{ data: { authorization_url: string; reference: string; access_code: string } }>(
          "https://api.paystack.co/transaction/initialize",
          {
            amount: amountInKobo,
            email,
            reference,
            currency: "GHS",
            mobile_money: { phone, provider: network.toLowerCase() },
            channels: ["mobile_money"],
          },
          { headers: paystackHeaders() }
        );
        paystackRes = data;
      } catch {
        // fallback if Paystack is not configured
      }
    }

    // Save payment record
    await db.insert(paymentsTable).values({
      reference,
      amount: String(amount),
      network,
      customerEmail: email,
      customerPhone: phone,
      status: "pending",
      purpose,
      bookingId: bookingId ?? null,
    });

    res.json({
      authorizationUrl: paystackRes?.data?.authorization_url ?? `https://paystack.com/pay/${reference}`,
      reference: paystackRes?.data?.reference ?? reference,
      accessCode: paystackRes?.data?.access_code ?? reference,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to initialize payment" });
  }
});

router.get("/payments/verify/:reference", async (req, res) => {
  try {
    const { reference } = req.params;
    if (!reference) { res.status(400).json({ error: "reference required" }); return; }

    let paystackStatus = "pending";
    let network: string | null = null;
    let customerPhone: string | null = null;
    let verifiedAmount = 0;

    if (PAYSTACK_SECRET) {
      try {
        const { data } = await axios.get<{
          data: {
            status: string;
            amount: number;
            authorization?: { bank?: string };
            customer?: { phone?: string };
            metadata?: { mobile_money?: { phone?: string; provider?: string } };
          };
        }>(
          `https://api.paystack.co/transaction/verify/${reference}`,
          { headers: paystackHeaders() }
        );
        paystackStatus = data.data.status === "success" ? "success" : data.data.status;
        verifiedAmount = data.data.amount / 100;
        network = data.data.authorization?.bank ?? null;
        customerPhone = data.data.customer?.phone ?? null;

        // Update payment status in DB
        await db.update(paymentsTable).set({ status: paystackStatus, updatedAt: new Date() }).where(eq(paymentsTable.reference, reference));
      } catch {
        // ignore
      }
    }

    const [payment] = await db.select().from(paymentsTable).where(eq(paymentsTable.reference, reference));
    res.json({
      status: paystackStatus || payment?.status || "pending",
      reference,
      amount: verifiedAmount || Number(payment?.amount ?? 0),
      network: network || payment?.network,
      customerPhone: customerPhone || payment?.customerPhone,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to verify payment" });
  }
});

router.post("/payments/webhook", async (req, res) => {
  try {
    const event = req.body;
    if (event?.event === "charge.success") {
      const reference = event?.data?.reference;
      if (reference) {
        await db.update(paymentsTable).set({ status: "success", updatedAt: new Date() }).where(eq(paymentsTable.reference, reference));
      }
    }
    res.sendStatus(200);
  } catch {
    res.sendStatus(200);
  }
});

router.get("/payments/export", requireAuth, async (req, res) => {
  try {
    const rows = await db.select().from(paymentsTable).orderBy(desc(paymentsTable.createdAt));
    const csv = [
      "ID,Reference,Amount(GHS),Network,Email,Phone,Status,Purpose,Date",
      ...rows.map((p) =>
        `${p.id},"${p.reference}",${Number(p.amount)},"${p.network ?? ""}","${p.customerEmail ?? ""}","${p.customerPhone ?? ""}","${p.status}","${p.purpose ?? ""}","${p.createdAt.toISOString()}"`
      ),
    ].join("\n");
    res.setHeader("Content-Type", "text/csv");
    res.setHeader("Content-Disposition", "attachment; filename=payments.csv");
    res.send(csv);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to export payments" });
  }
});

router.get("/payments/revenue", requireAuth, async (req, res) => {
  try {
    const [successful] = await db.select({ count: sql<number>`count(*)::int`, total: sql<number>`coalesce(sum(amount::numeric),0)::float` }).from(paymentsTable).where(eq(paymentsTable.status, "success"));
    const [pending] = await db.select({ count: sql<number>`count(*)::int` }).from(paymentsTable).where(eq(paymentsTable.status, "pending"));
    const [failed] = await db.select({ count: sql<number>`count(*)::int` }).from(paymentsTable).where(eq(paymentsTable.status, "failed"));

    res.json({
      totalRevenue: successful?.total ?? 0,
      successfulPayments: successful?.count ?? 0,
      pendingPayments: pending?.count ?? 0,
      failedPayments: failed?.count ?? 0,
      revenueByNetwork: {},
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch revenue stats" });
  }
});

router.get("/payments", requireAuth, async (req, res) => {
  try {
    const { status, network } = req.query as { status?: string; network?: string };
    const rows = await db.select().from(paymentsTable).orderBy(desc(paymentsTable.createdAt));
    const filtered = rows.filter((p) => {
      if (status && p.status !== status) return false;
      if (network && p.network !== network) return false;
      return true;
    });
    res.json(filtered.map((p) => ({
      id: p.id,
      reference: p.reference,
      amount: Number(p.amount),
      network: p.network,
      customerEmail: p.customerEmail,
      customerPhone: p.customerPhone,
      status: p.status,
      purpose: p.purpose,
      bookingId: p.bookingId,
      createdAt: p.createdAt.toISOString(),
    })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch payments" });
  }
});

router.post("/payments/:id/refund", requireAuth, async (req, res) => {
  const id = parseInt(req.params.id as string ?? "");
  if (isNaN(id)) { res.status(400).json({ error: "Invalid ID" }); return; }
  try {
    const [payment] = await db.select().from(paymentsTable).where(eq(paymentsTable.id, id));
    if (!payment) { res.status(404).json({ error: "Payment not found" }); return; }

    if (PAYSTACK_SECRET) {
      try {
        await axios.post(
          "https://api.paystack.co/refund",
          { transaction: payment.reference },
          { headers: paystackHeaders() }
        );
      } catch {
        // ignore Paystack error, proceed with local update
      }
    }
    await db.update(paymentsTable).set({ status: "refunded", updatedAt: new Date() }).where(eq(paymentsTable.id, id));
    res.json({ message: "Refund processed" });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to process refund" });
  }
});

export default router;
