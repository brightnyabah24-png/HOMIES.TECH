import { Router, type IRouter } from "express";
import healthRouter from "./health";
import productsRouter from "./products";
import servicesRouter from "./services";
import bookingsRouter from "./bookings";
import trackingRouter from "./tracking";
import reviewsRouter from "./reviews";
import adminRouter from "./admin";
import dashboardRouter from "./dashboard";
import paymentsRouter from "./payments";
import contactRouter from "./contact";
import storageRouter from "./storage";

const router: IRouter = Router();

router.use(healthRouter);
router.use(storageRouter);
router.use(productsRouter);
router.use(servicesRouter);
router.use(bookingsRouter);
router.use(trackingRouter);
router.use(reviewsRouter);
router.use(adminRouter);
router.use(dashboardRouter);
router.use(paymentsRouter);
router.use(contactRouter);

export default router;
