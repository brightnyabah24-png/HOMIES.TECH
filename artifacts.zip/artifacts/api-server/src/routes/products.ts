import { Router } from "express";
import { db } from "@workspace/db";
import { productsTable } from "@workspace/db";
import { eq, ilike, and, type SQL } from "drizzle-orm";
import { requireAuth } from "../lib/auth";

const router = Router();

router.get("/products/categories", async (req, res) => {
  try {
    const rows = await db.selectDistinct({ category: productsTable.category }).from(productsTable);
    res.json(rows.map((r) => r.category));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch categories" });
  }
});

router.get("/products", async (req, res) => {
  try {
    const { category, search, inStock } = req.query as {
      category?: string;
      search?: string;
      inStock?: string;
    };

    const conditions: SQL[] = [];
    if (category) conditions.push(eq(productsTable.category, category));
    if (search) conditions.push(ilike(productsTable.name, `%${search}%`));
    if (inStock === "true") conditions.push(eq(productsTable.inStock, true));
    if (inStock === "false") conditions.push(eq(productsTable.inStock, false));

    const products = conditions.length > 0
      ? await db.select().from(productsTable).where(and(...conditions)).orderBy(productsTable.id)
      : await db.select().from(productsTable).orderBy(productsTable.id);

    res.json(products.map(formatProduct));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch products" });
  }
});

router.get("/products/:id", async (req, res) => {
  const id = parseInt(req.params.id as string ?? "");
  if (isNaN(id)) { res.status(400).json({ error: "Invalid ID" }); return; }
  try {
    const [product] = await db.select().from(productsTable).where(eq(productsTable.id, id));
    if (!product) { res.status(404).json({ error: "Not found" }); return; }
    res.json(formatProduct(product));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch product" });
  }
});

router.post("/products", requireAuth, async (req, res) => {
  try {
    const { name, description, price, category, imageUrl, inStock = true, stockCount } = req.body;
    if (!name || price == null || !category) {
      res.status(400).json({ error: "name, price, category required" });
      return;
    }
    const [product] = await db.insert(productsTable).values({
      name, description, price: String(price), category, imageUrl, inStock, stockCount,
    }).returning();
    res.status(201).json(formatProduct(product!));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create product" });
  }
});

router.patch("/products/:id", requireAuth, async (req, res) => {
  const id = parseInt(req.params.id as string ?? "");
  if (isNaN(id)) { res.status(400).json({ error: "Invalid ID" }); return; }
  try {
    const { name, description, price, category, imageUrl, inStock, stockCount } = req.body;
    const updates: Record<string, unknown> = { updatedAt: new Date() };
    if (name !== undefined) updates["name"] = name;
    if (description !== undefined) updates["description"] = description;
    if (price !== undefined) updates["price"] = String(price);
    if (category !== undefined) updates["category"] = category;
    if (imageUrl !== undefined) updates["imageUrl"] = imageUrl;
    if (inStock !== undefined) updates["inStock"] = inStock;
    if (stockCount !== undefined) updates["stockCount"] = stockCount;
    const [product] = await db.update(productsTable).set(updates).where(eq(productsTable.id, id)).returning();
    if (!product) { res.status(404).json({ error: "Not found" }); return; }
    res.json(formatProduct(product));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update product" });
  }
});

router.delete("/products/:id", requireAuth, async (req, res) => {
  const id = parseInt(req.params.id as string ?? "");
  if (isNaN(id)) { res.status(400).json({ error: "Invalid ID" }); return; }
  try {
    await db.delete(productsTable).where(eq(productsTable.id, id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete product" });
  }
});

function formatProduct(p: typeof productsTable.$inferSelect) {
  return {
    id: p.id,
    name: p.name,
    description: p.description,
    price: Number(p.price),
    category: p.category,
    imageUrl: p.imageUrl,
    inStock: p.inStock,
    stockCount: p.stockCount,
    createdAt: p.createdAt.toISOString(),
  };
}

export default router;
