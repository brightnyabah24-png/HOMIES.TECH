import { Router } from "express";
import { db } from "@workspace/db";
import { reviewsTable } from "@workspace/db";
import { eq, and, desc } from "drizzle-orm";
import { requireAuth } from "../lib/auth";

const router = Router();

router.get("/reviews", async (req, res) => {
  try {
    const { featured } = req.query as { featured?: string };
    const conditions = [eq(reviewsTable.status, "approved")];
    if (featured === "true") conditions.push(eq(reviewsTable.featured, true));
    const rows = await db.select().from(reviewsTable).where(and(...conditions)).orderBy(desc(reviewsTable.createdAt));
    res.json(rows.map(formatReview));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch reviews" });
  }
});

router.post("/reviews", async (req, res) => {
  try {
    const { name, rating, comment, photoUrl } = req.body;
    if (!name || !rating || !comment) {
      res.status(400).json({ error: "name, rating, comment required" });
      return;
    }
    if (rating < 1 || rating > 5) {
      res.status(400).json({ error: "rating must be 1-5" });
      return;
    }
    const [review] = await db.insert(reviewsTable).values({ name, rating, comment, photoUrl }).returning();
    res.status(201).json(formatReview(review!));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to submit review" });
  }
});

router.get("/reviews/admin", requireAuth, async (req, res) => {
  try {
    const rows = await db.select().from(reviewsTable).orderBy(desc(reviewsTable.createdAt));
    res.json(rows.map(formatReview));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch reviews" });
  }
});

router.patch("/reviews/:id", requireAuth, async (req, res) => {
  const id = parseInt(req.params.id as string ?? "");
  if (isNaN(id)) { res.status(400).json({ error: "Invalid ID" }); return; }
  try {
    const { status, featured } = req.body;
    const updates: Record<string, unknown> = {};
    if (status !== undefined) updates["status"] = status;
    if (featured !== undefined) updates["featured"] = featured;
    const [review] = await db.update(reviewsTable).set(updates).where(eq(reviewsTable.id, id)).returning();
    if (!review) { res.status(404).json({ error: "Not found" }); return; }
    res.json(formatReview(review));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update review" });
  }
});

router.delete("/reviews/:id", requireAuth, async (req, res) => {
  const id = parseInt(req.params.id as string ?? "");
  if (isNaN(id)) { res.status(400).json({ error: "Invalid ID" }); return; }
  try {
    await db.delete(reviewsTable).where(eq(reviewsTable.id, id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete review" });
  }
});

function formatReview(r: typeof reviewsTable.$inferSelect) {
  return {
    id: r.id,
    name: r.name,
    rating: r.rating,
    comment: r.comment,
    photoUrl: r.photoUrl,
    status: r.status,
    featured: r.featured,
    createdAt: r.createdAt.toISOString(),
  };
}

export default router;
