import { Router } from "express";
import { db } from "@workspace/db";
import { adminUsersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { signToken, requireAuth, verifyToken } from "../lib/auth";
import type { Request } from "express";

const router = Router();

type AuthedRequest = Request & { admin?: { id: number; username: string } };

router.post("/admin/login", async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      res.status(400).json({ error: "username and password required" });
      return;
    }
    const [user] = await db.select().from(adminUsersTable).where(eq(adminUsersTable.username, username));
    if (!user) {
      res.status(401).json({ error: "Invalid credentials" });
      return;
    }
    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) {
      res.status(401).json({ error: "Invalid credentials" });
      return;
    }
    const token = signToken({ id: user.id, username: user.username });
    res.json({
      token,
      user: { id: user.id, username: user.username, requiresPasswordChange: user.requiresPasswordChange },
      requiresPasswordChange: user.requiresPasswordChange,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Login failed" });
  }
});

router.post("/admin/logout", (_req, res) => {
  res.json({ message: "Logged out" });
});

router.get("/admin/me", requireAuth, async (req: AuthedRequest, res) => {
  try {
    const adminPayload = req.admin;
    if (!adminPayload) { res.status(401).json({ error: "Unauthorized" }); return; }
    const [user] = await db.select().from(adminUsersTable).where(eq(adminUsersTable.id, adminPayload.id));
    if (!user) { res.status(401).json({ error: "User not found" }); return; }
    res.json({ id: user.id, username: user.username, requiresPasswordChange: user.requiresPasswordChange });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch admin" });
  }
});

router.post("/admin/change-password", requireAuth, async (req: AuthedRequest, res) => {
  try {
    const adminPayload = req.admin;
    if (!adminPayload) { res.status(401).json({ error: "Unauthorized" }); return; }
    const { oldPassword, newPassword } = req.body;
    if (!oldPassword || !newPassword) {
      res.status(400).json({ error: "oldPassword and newPassword required" });
      return;
    }
    const [user] = await db.select().from(adminUsersTable).where(eq(adminUsersTable.id, adminPayload.id));
    if (!user) { res.status(404).json({ error: "User not found" }); return; }
    const valid = await bcrypt.compare(oldPassword, user.passwordHash);
    if (!valid) {
      res.status(400).json({ error: "Current password is incorrect" });
      return;
    }
    const hash = await bcrypt.hash(newPassword, 12);
    await db.update(adminUsersTable).set({ passwordHash: hash, requiresPasswordChange: false, updatedAt: new Date() }).where(eq(adminUsersTable.id, user.id));
    res.json({ message: "Password changed successfully" });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to change password" });
  }
});

export default router;
