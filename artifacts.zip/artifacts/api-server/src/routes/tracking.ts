import { Router } from "express";
import { db } from "@workspace/db";
import { deviceTrackingTable } from "@workspace/db";
import { eq, and, desc } from "drizzle-orm";
import { requireAuth } from "../lib/auth";

const router = Router();

router.get("/tracking", requireAuth, async (req, res) => {
  try {
    const rows = await db.select().from(deviceTrackingTable).orderBy(desc(deviceTrackingTable.createdAt));
    res.json(rows.map(formatTracking));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch tracking" });
  }
});

router.get("/tracking/lookup", async (req, res) => {
  try {
    const { trackingId, phone } = req.query as { trackingId?: string; phone?: string };
    if (!trackingId || !phone) {
      res.status(400).json({ error: "trackingId and phone required" });
      return;
    }
    const [row] = await db.select().from(deviceTrackingTable).where(
      and(
        eq(deviceTrackingTable.trackingId, trackingId.toUpperCase()),
        eq(deviceTrackingTable.customerPhone, phone)
      )
    );
    if (!row) {
      res.status(404).json({ error: "Device not found" });
      return;
    }
    res.json(formatTracking(row));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to lookup tracking" });
  }
});

router.patch("/tracking/:id", requireAuth, async (req, res) => {
  const id = parseInt(req.params.id as string ?? "");
  if (isNaN(id)) { res.status(400).json({ error: "Invalid ID" }); return; }
  try {
    const { currentStatus, technicianNotes } = req.body;
    if (!currentStatus) { res.status(400).json({ error: "currentStatus required" }); return; }

    const [existing] = await db.select().from(deviceTrackingTable).where(eq(deviceTrackingTable.id, id));
    if (!existing) { res.status(404).json({ error: "Not found" }); return; }

    const history = Array.isArray(existing.statusHistory) ? existing.statusHistory as Array<{status: string; timestamp: string; note?: string}> : [];
    history.push({ status: currentStatus, timestamp: new Date().toISOString(), note: technicianNotes });

    const updates: Record<string, unknown> = {
      currentStatus,
      statusHistory: JSON.stringify(history),
      updatedAt: new Date(),
    };
    if (technicianNotes !== undefined) updates["technicianNotes"] = technicianNotes;

    const [row] = await db.update(deviceTrackingTable).set(updates).where(eq(deviceTrackingTable.id, id)).returning();
    res.json(formatTracking(row!));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update tracking" });
  }
});

function formatTracking(t: typeof deviceTrackingTable.$inferSelect) {
  let statusHistory: Array<{status: string; timestamp: string; note?: string | null}> = [];
  try {
    statusHistory = Array.isArray(t.statusHistory) ? t.statusHistory as typeof statusHistory : JSON.parse(t.statusHistory as string ?? "[]");
  } catch {
    statusHistory = [];
  }
  return {
    id: t.id,
    trackingId: t.trackingId,
    customerName: t.customerName,
    customerPhone: t.customerPhone,
    deviceType: t.deviceType,
    brand: t.brand,
    currentStatus: t.currentStatus,
    technicianNotes: t.technicianNotes,
    qrCodeUrl: t.qrCodeUrl,
    statusHistory,
    createdAt: t.createdAt.toISOString(),
    updatedAt: t.updatedAt.toISOString(),
  };
}

export default router;
