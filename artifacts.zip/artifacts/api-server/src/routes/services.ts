import { Router } from "express";
import { db } from "@workspace/db";
import { repairServicesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth } from "../lib/auth";

const router = Router();

router.get("/services", async (req, res) => {
  try {
    const { deviceType } = req.query as { deviceType?: string };
    const services = deviceType
      ? await db.select().from(repairServicesTable).where(eq(repairServicesTable.deviceType, deviceType)).orderBy(repairServicesTable.id)
      : await db.select().from(repairServicesTable).orderBy(repairServicesTable.id);
    res.json(services.map(formatService));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch services" });
  }
});

router.post("/services", requireAuth, async (req, res) => {
  try {
    const { name, deviceType, price, estimatedTime, description } = req.body;
    if (!name || !deviceType || !estimatedTime) {
      res.status(400).json({ error: "name, deviceType, estimatedTime required" });
      return;
    }
    const [service] = await db.insert(repairServicesTable).values({
      name, deviceType, price: price != null ? String(price) : null, estimatedTime, description,
    }).returning();
    res.status(201).json(formatService(service!));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create service" });
  }
});

router.patch("/services/:id", requireAuth, async (req, res) => {
  const id = parseInt(req.params.id as string ?? "");
  if (isNaN(id)) { res.status(400).json({ error: "Invalid ID" }); return; }
  try {
    const { name, price, estimatedTime, description } = req.body;
    const updates: Record<string, unknown> = { updatedAt: new Date() };
    if (name !== undefined) updates["name"] = name;
    if (price !== undefined) updates["price"] = price != null ? String(price) : null;
    if (estimatedTime !== undefined) updates["estimatedTime"] = estimatedTime;
    if (description !== undefined) updates["description"] = description;
    const [service] = await db.update(repairServicesTable).set(updates).where(eq(repairServicesTable.id, id)).returning();
    if (!service) { res.status(404).json({ error: "Not found" }); return; }
    res.json(formatService(service));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update service" });
  }
});

router.delete("/services/:id", requireAuth, async (req, res) => {
  const id = parseInt(req.params.id as string ?? "");
  if (isNaN(id)) { res.status(400).json({ error: "Invalid ID" }); return; }
  try {
    await db.delete(repairServicesTable).where(eq(repairServicesTable.id, id));
    res.status(204).send();
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to delete service" });
  }
});

function formatService(s: typeof repairServicesTable.$inferSelect) {
  return {
    id: s.id,
    name: s.name,
    deviceType: s.deviceType,
    price: s.price != null ? Number(s.price) : null,
    estimatedTime: s.estimatedTime,
    description: s.description,
  };
}

export default router;
