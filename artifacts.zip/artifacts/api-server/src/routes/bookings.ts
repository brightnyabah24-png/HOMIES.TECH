import { Router } from "express";
import { db } from "@workspace/db";
import { bookingsTable, deviceTrackingTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { requireAuth } from "../lib/auth";
import {
  sendBookingNotificationToAdmin,
  sendBookingConfirmationToCustomer,
  sendRepairReadyNotification,
} from "../lib/notifications";
import QRCode from "qrcode";

const router = Router();

function generateTrackingId(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let result = "HT-";
  for (let i = 0; i < 6; i++) {
    result += chars[Math.floor(Math.random() * chars.length)];
  }
  return result;
}

async function generateQRCode(trackingId: string): Promise<string> {
  try {
    return await QRCode.toDataURL(`https://homiestech.com/tracking?id=${trackingId}`);
  } catch {
    return "";
  }
}

router.get("/bookings", requireAuth, async (req, res) => {
  try {
    const { status } = req.query as { status?: string };
    const rows = status
      ? await db.select().from(bookingsTable).where(eq(bookingsTable.status, status)).orderBy(desc(bookingsTable.createdAt))
      : await db.select().from(bookingsTable).orderBy(desc(bookingsTable.createdAt));
    res.json(rows.map(formatBooking));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch bookings" });
  }
});

router.post("/bookings", async (req, res) => {
  try {
    const {
      fullName, phone, email, deviceType, brand, problemDescription,
      preferredDate, preferredTime, serviceType,
    } = req.body;

    if (!fullName || !phone || !deviceType || !brand || !problemDescription || !preferredDate || !serviceType) {
      res.status(400).json({ error: "Missing required fields" });
      return;
    }

    const trackingId = generateTrackingId();
    const qrCodeUrl = await generateQRCode(trackingId);

    const [booking] = await db.insert(bookingsTable).values({
      fullName, phone, email, deviceType, brand, problemDescription,
      preferredDate, preferredTime, serviceType, trackingId,
    }).returning();

    // Create device tracking entry
    await db.insert(deviceTrackingTable).values({
      trackingId,
      customerName: fullName,
      customerPhone: phone,
      deviceType,
      brand,
      currentStatus: "received",
      qrCodeUrl,
      statusHistory: JSON.stringify([{ status: "received", timestamp: new Date().toISOString(), note: "Device booking received" }]),
    });

    // Send notifications (non-blocking)
    sendBookingNotificationToAdmin({ fullName, phone, email, deviceType, brand, problemDescription, preferredDate, preferredTime, serviceType, trackingId }).catch(() => {});
    if (email) sendBookingConfirmationToCustomer({ fullName, phone, email, trackingId, deviceType, brand, preferredDate }).catch(() => {});

    res.status(201).json({
      booking: formatBooking(booking!),
      trackingId,
      qrCodeUrl,
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to create booking" });
  }
});

router.get("/bookings/:id", requireAuth, async (req, res) => {
  const id = parseInt(req.params.id as string ?? "");
  if (isNaN(id)) { res.status(400).json({ error: "Invalid ID" }); return; }
  try {
    const [booking] = await db.select().from(bookingsTable).where(eq(bookingsTable.id, id));
    if (!booking) { res.status(404).json({ error: "Not found" }); return; }
    res.json(formatBooking(booking));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch booking" });
  }
});

router.patch("/bookings/:id", requireAuth, async (req, res) => {
  const id = parseInt(req.params.id as string ?? "");
  if (isNaN(id)) { res.status(400).json({ error: "Invalid ID" }); return; }
  try {
    const { status, technicianNotes, depositPaid } = req.body;
    const updates: Record<string, unknown> = { updatedAt: new Date() };
    if (status !== undefined) updates["status"] = status;
    if (technicianNotes !== undefined) updates["technicianNotes"] = technicianNotes;
    if (depositPaid !== undefined) updates["depositPaid"] = depositPaid;

    const [booking] = await db.update(bookingsTable).set(updates).where(eq(bookingsTable.id, id)).returning();
    if (!booking) { res.status(404).json({ error: "Not found" }); return; }

    // Send repair ready notification
    if (status === "completed" || status === "ready") {
      sendRepairReadyNotification({ fullName: booking.fullName, phone: booking.phone, email: booking.email, trackingId: booking.trackingId }).catch(() => {});
    }

    res.json(formatBooking(booking));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update booking" });
  }
});

function formatBooking(b: typeof bookingsTable.$inferSelect) {
  return {
    id: b.id,
    fullName: b.fullName,
    phone: b.phone,
    email: b.email,
    deviceType: b.deviceType,
    brand: b.brand,
    problemDescription: b.problemDescription,
    preferredDate: b.preferredDate,
    preferredTime: b.preferredTime,
    serviceType: b.serviceType,
    status: b.status,
    trackingId: b.trackingId,
    depositPaid: b.depositPaid,
    depositAmount: b.depositAmount != null ? Number(b.depositAmount) : null,
    technicianNotes: b.technicianNotes,
    createdAt: b.createdAt.toISOString(),
  };
}

export default router;
