import "express";

declare module "express" {
  interface Request {
    admin?: {
      id: number;
      username: string;
    };
  }
}
