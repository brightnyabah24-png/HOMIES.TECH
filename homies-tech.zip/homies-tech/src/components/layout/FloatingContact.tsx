import { Phone, MessageCircle } from "lucide-react";
import { motion } from "framer-motion";

export function FloatingContact() {
  return (
    <div className="fixed bottom-6 left-0 right-0 z-50 flex justify-between px-6 pointer-events-none">
      <motion.a
        href="tel:+233256992268"
        className="pointer-events-auto flex h-14 w-14 items-center justify-center rounded-full bg-destructive text-white shadow-lg hover:bg-destructive/90 transition-colors"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <Phone className="h-6 w-6" />
        <span className="sr-only">Call Us</span>
      </motion.a>

      <motion.a
        href="https://wa.me/233552929516"
        target="_blank"
        rel="noreferrer"
        className="pointer-events-auto flex h-14 w-14 items-center justify-center rounded-full bg-green-500 text-white shadow-lg hover:bg-green-600 transition-colors relative"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-green-400 opacity-75"></span>
        <MessageCircle className="h-6 w-6 relative z-10" />
        <span className="sr-only">WhatsApp Us</span>
      </motion.a>
    </div>
  );
}
