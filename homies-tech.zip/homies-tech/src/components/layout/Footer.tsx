import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="border-t bg-card text-card-foreground">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          <div className="space-y-4">
            <div className="dark:bg-transparent bg-foreground p-2 rounded-lg inline-block">
              <img src="/logo.png" alt="Homies Tech" className="h-10 object-contain" />
            </div>
            <p className="text-sm text-muted-foreground">
              Tamale's premium destination for phone and laptop repairs. A young man with vision, mission, and ambition.
            </p>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-lg font-display">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/phone-repair" className="text-muted-foreground hover:text-primary transition-colors">
                  Phone Repair
                </Link>
              </li>
              <li>
                <Link href="/laptop-repair" className="text-muted-foreground hover:text-primary transition-colors">
                  Laptop Repair
                </Link>
              </li>
              <li>
                <Link href="/shop" className="text-muted-foreground hover:text-primary transition-colors">
                  Accessories Shop
                </Link>
              </li>
              <li>
                <Link href="/tracking" className="text-muted-foreground hover:text-primary transition-colors">
                  Track Device
                </Link>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-lg font-display">Contact Us</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Tamale, Ghana</li>
              <li>
                <a href="tel:+233256992268" className="hover:text-primary transition-colors">
                  +233 25 699 2268
                </a>
              </li>
              <li>
                <a href="https://wa.me/233552929516" target="_blank" rel="noreferrer" className="hover:text-primary transition-colors">
                  WhatsApp: +233 55 292 9516
                </a>
              </li>
              <li>
                <a href="mailto:homiestech1@gmail.com" className="hover:text-primary transition-colors">
                  homiestech1@gmail.com
                </a>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-lg font-display">Business Hours</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Mon - Fri: 8:00 AM - 7:00 PM</li>
              <li>Sat: 9:00 AM - 6:00 PM</li>
              <li>Sun: 12:00 PM - 5:00 PM</li>
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} Homies Tech. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
