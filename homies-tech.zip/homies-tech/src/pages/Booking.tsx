import { useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { FloatingContact } from "@/components/layout/FloatingContact";
import { useCreateBooking, useInitializePayment } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle2, QrCode } from "lucide-react";
import { motion } from "framer-motion";

export default function Booking() {
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    fullName: "",
    phone: "",
    email: "",
    deviceType: "phone",
    brand: "",
    problemDescription: "",
    preferredDate: "",
    preferredTime: "",
    serviceType: "Visit Shop"
  });
  
  const [payDeposit, setPayDeposit] = useState(false);
  const [depositAmount, setDepositAmount] = useState("50");
  const [network, setNetwork] = useState("mtn");
  
  const [successData, setSuccessData] = useState<{trackingId: string, qrCodeUrl: string} | null>(null);

  const createBooking = useCreateBooking({
    mutation: {
      onSuccess: (data: any) => {
        setSuccessData({ trackingId: data.trackingId, qrCodeUrl: data.qrCodeUrl });
        toast({ title: "Booking Confirmed!" });
      },
      onError: () => {
        toast({ title: "Error", description: "Failed to submit booking.", variant: "destructive" });
      }
    }
  });

  const initPayment = useInitializePayment({
    mutation: {
      onSuccess: (data: any) => {
        window.location.href = data.authorizationUrl;
      },
      onError: () => {
        toast({ title: "Payment Error", description: "Failed to initialize payment.", variant: "destructive" });
      }
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName || !formData.phone || !formData.brand || !formData.problemDescription || !formData.preferredDate) {
      toast({ title: "Validation Error", description: "Please fill all required fields.", variant: "destructive" });
      return;
    }

    if (payDeposit) {
      // First create booking, then init payment
      // For simplicity, we just init payment right away and pass booking data to redirect if possible,
      // But the API flow implies booking creation first.
      createBooking.mutate({ 
        data: { 
          ...formData, 
          payDeposit: true, 
          depositAmount: Number(depositAmount) 
        } 
      }, {
        onSuccess: (res: any) => {
          initPayment.mutate({
            data: {
              amount: Number(depositAmount),
              email: formData.email || "homiestech1@gmail.com",
              phone: formData.phone,
              network: network,
              bookingId: res.booking.id,
              purpose: "Repair Deposit"
            }
          });
        }
      });
    } else {
      createBooking.mutate({ data: formData });
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  if (successData) {
    return (
      <div className="flex min-h-screen flex-col">
        <Navbar />
        <main className="flex-1 bg-background flex items-center justify-center py-16">
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="max-w-md w-full bg-card border rounded-3xl p-8 text-center shadow-lg">
            <div className="h-20 w-20 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 className="h-10 w-10 text-green-600 dark:text-green-400" />
            </div>
            <h2 className="font-display text-3xl font-bold mb-2">Booking Confirmed!</h2>
            <p className="text-muted-foreground mb-6">Your repair has been successfully booked.</p>
            
            <div className="bg-muted rounded-xl p-4 mb-6">
              <p className="text-sm font-medium mb-1">Your Tracking ID</p>
              <div className="text-2xl font-bold font-mono tracking-wider text-primary">{successData.trackingId}</div>
            </div>

            {successData.qrCodeUrl && (
              <div className="flex flex-col items-center justify-center mb-6">
                <p className="text-sm font-medium mb-2">Scan to track</p>
                <div className="bg-white p-2 rounded-xl border">
                  <img src={successData.qrCodeUrl} alt="Tracking QR Code" className="h-32 w-32" />
                </div>
              </div>
            )}

            <Button onClick={() => window.location.href = "/"} className="w-full h-12 rounded-xl">
              Return to Home
            </Button>
          </motion.div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      
      <main className="flex-1 bg-background py-16">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="text-center mb-10">
            <h1 className="font-display text-4xl font-bold">Book a Repair</h1>
            <p className="mt-2 text-muted-foreground">Tell us about your device issue and schedule an appointment.</p>
          </div>

          <div className="bg-card border rounded-3xl p-6 md:p-10 shadow-sm">
            <form onSubmit={handleSubmit} className="space-y-8">
              
              {/* Personal Info */}
              <div className="space-y-4">
                <h3 className="text-xl font-bold font-display border-b pb-2">Personal Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Full Name *</Label>
                    <Input id="fullName" value={formData.fullName} onChange={(e) => handleInputChange("fullName", e.target.value)} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number *</Label>
                    <Input id="phone" value={formData.phone} onChange={(e) => handleInputChange("phone", e.target.value)} required />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="email">Email Address (Optional)</Label>
                    <Input id="email" type="email" value={formData.email} onChange={(e) => handleInputChange("email", e.target.value)} />
                  </div>
                </div>
              </div>

              {/* Device Info */}
              <div className="space-y-4">
                <h3 className="text-xl font-bold font-display border-b pb-2">Device Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Device Type *</Label>
                    <Select value={formData.deviceType} onValueChange={(val) => handleInputChange("deviceType", val)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="phone">Phone</SelectItem>
                        <SelectItem value="laptop">Laptop</SelectItem>
                        <SelectItem value="tablet">Tablet</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="brand">Brand / Model *</Label>
                    <Input id="brand" placeholder="e.g. iPhone 13 Pro" value={formData.brand} onChange={(e) => handleInputChange("brand", e.target.value)} required />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="problem">Problem Description *</Label>
                    <Textarea 
                      id="problem" 
                      placeholder="Describe the issue you're facing..." 
                      value={formData.problemDescription} 
                      onChange={(e) => handleInputChange("problemDescription", e.target.value)} 
                      rows={4} 
                      required 
                    />
                  </div>
                </div>
              </div>

              {/* Service Details */}
              <div className="space-y-4">
                <h3 className="text-xl font-bold font-display border-b pb-2">Service Preferences</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="date">Preferred Date *</Label>
                    <Input id="date" type="date" value={formData.preferredDate} onChange={(e) => handleInputChange("preferredDate", e.target.value)} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="time">Preferred Time (Optional)</Label>
                    <Input id="time" type="time" value={formData.preferredTime} onChange={(e) => handleInputChange("preferredTime", e.target.value)} />
                  </div>
                  <div className="space-y-3 md:col-span-2 mt-2">
                    <Label>Service Type *</Label>
                    <RadioGroup value={formData.serviceType} onValueChange={(val) => handleInputChange("serviceType", val)} className="flex flex-col sm:flex-row gap-4">
                      <div className="flex items-center space-x-2 border p-4 rounded-xl flex-1 cursor-pointer hover:bg-muted/50">
                        <RadioGroupItem value="Visit Shop" id="r-shop" />
                        <Label htmlFor="r-shop" className="cursor-pointer font-medium">Visit Shop</Label>
                      </div>
                      <div className="flex items-center space-x-2 border p-4 rounded-xl flex-1 cursor-pointer hover:bg-muted/50">
                        <RadioGroupItem value="Home Service" id="r-home" />
                        <Label htmlFor="r-home" className="cursor-pointer font-medium">Home Service</Label>
                      </div>
                      <div className="flex items-center space-x-2 border p-4 rounded-xl flex-1 cursor-pointer hover:bg-muted/50">
                        <RadioGroupItem value="Meet Up" id="r-meet" />
                        <Label htmlFor="r-meet" className="cursor-pointer font-medium">Meet Up</Label>
                      </div>
                    </RadioGroup>
                  </div>
                </div>
              </div>

              {/* Deposit section */}
              <div className="space-y-4 border rounded-2xl p-6 bg-muted/30">
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="deposit" 
                    checked={payDeposit} 
                    onCheckedChange={(c) => setPayDeposit(c as boolean)} 
                  />
                  <Label htmlFor="deposit" className="text-base font-semibold cursor-pointer">
                    Pay Repair Deposit (Priority Service)
                  </Label>
                </div>
                
                {payDeposit && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} className="space-y-4 pt-4 overflow-hidden">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Deposit Amount (GH₵)</Label>
                        <Input type="number" value={depositAmount} onChange={(e) => setDepositAmount(e.target.value)} min="10" />
                      </div>
                      <div className="space-y-2">
                        <Label>Mobile Money Network</Label>
                        <Select value={network} onValueChange={setNetwork}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select network" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="mtn">MTN</SelectItem>
                            <SelectItem value="vod">Vodafone</SelectItem>
                            <SelectItem value="tgo">AirtelTigo</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </motion.div>
                )}
              </div>

              <Button type="submit" className="w-full h-14 text-lg rounded-xl" disabled={createBooking.isPending || initPayment.isPending}>
                {createBooking.isPending || initPayment.isPending ? "Processing..." : (payDeposit ? "Proceed to Payment" : "Confirm Booking")}
              </Button>
            </form>
          </div>
        </div>
      </main>

      <FloatingContact />
      <Footer />
    </div>
  );
}
