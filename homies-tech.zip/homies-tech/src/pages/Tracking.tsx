import { useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { FloatingContact } from "@/components/layout/FloatingContact";
import { useLookupTracking, getLookupTrackingQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Search, CheckCircle2, Clock, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";

const STEPS = [
  "Received",
  "Under Diagnosis",
  "Awaiting Parts",
  "Repair In Progress",
  "Quality Check",
  "Ready for Pickup",
  "Delivered"
];

export default function Tracking() {
  const [trackingId, setTrackingId] = useState("");
  const [phone, setPhone] = useState("");
  const [searchParams, setSearchParams] = useState<{trackingId: string, phone: string} | null>(null);
  const { toast } = useToast();

  const { data: trackingData, isLoading, isError, error } = useQuery({
    queryKey: getLookupTrackingQueryKey(searchParams!),
    queryFn: async () => {
      // Manual fetch as we only want it to run when searchParams is set
      const res = await fetch(`/api/tracking/lookup?trackingId=${searchParams!.trackingId}&phone=${searchParams!.phone}`);
      if (!res.ok) throw new Error("Tracking not found");
      return res.json();
    },
    enabled: !!searchParams,
    retry: false
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!trackingId || !phone) {
      toast({ title: "Error", description: "Please enter both Tracking ID and Phone Number", variant: "destructive" });
      return;
    }
    setSearchParams({ trackingId, phone });
  };

  const getCurrentStepIndex = (status: string) => {
    return STEPS.findIndex(s => s.toLowerCase() === status.toLowerCase());
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      
      <main className="flex-1 bg-background py-16">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="text-center mb-10">
            <h1 className="font-display text-4xl font-bold">Track Your Device</h1>
            <p className="mt-2 text-muted-foreground">Enter your tracking ID and phone number to see the current status of your repair.</p>
          </div>

          <Card className="mb-10">
            <CardContent className="pt-6">
              <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-4 items-end">
                <div className="space-y-2 flex-1 w-full">
                  <Label htmlFor="trackingId">Tracking ID</Label>
                  <Input 
                    id="trackingId" 
                    placeholder="e.g. HT-1234" 
                    value={trackingId}
                    onChange={(e) => setTrackingId(e.target.value)}
                  />
                </div>
                <div className="space-y-2 flex-1 w-full">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input 
                    id="phone" 
                    placeholder="e.g. 0552929516" 
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                  />
                </div>
                <Button type="submit" className="w-full sm:w-auto h-10 px-8" disabled={isLoading}>
                  {isLoading ? <Clock className="h-4 w-4 mr-2 animate-spin" /> : <Search className="h-4 w-4 mr-2" />}
                  Track Device
                </Button>
              </form>
            </CardContent>
          </Card>

          {isError && (
            <div className="rounded-xl border border-destructive/50 bg-destructive/10 p-6 text-center text-destructive">
              <AlertCircle className="h-8 w-8 mx-auto mb-2" />
              <h3 className="font-semibold text-lg">Tracking Not Found</h3>
              <p>We couldn't find a repair with that Tracking ID and Phone combination. Please check and try again.</p>
            </div>
          )}

          {trackingData && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-3xl border bg-card p-6 md:p-10 shadow-sm"
            >
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b pb-6 mb-8 gap-4">
                <div>
                  <h2 className="text-2xl font-bold font-display">{trackingData.deviceType} - {trackingData.brand}</h2>
                  <p className="text-muted-foreground">Customer: {trackingData.customerName}</p>
                  <div className="mt-2 inline-flex items-center rounded-full bg-primary/10 px-3 py-1 text-sm font-medium text-primary">
                    ID: {trackingData.trackingId}
                  </div>
                </div>
                {trackingData.qrCodeUrl && (
                  <div className="rounded-xl border p-2 bg-white shrink-0">
                    <img src={trackingData.qrCodeUrl} alt="QR Code" className="h-24 w-24" />
                  </div>
                )}
              </div>

              <div className="relative pl-4 md:pl-8">
                <div className="absolute left-6 md:left-10 top-2 bottom-2 w-0.5 bg-muted"></div>
                
                <div className="space-y-8">
                  {STEPS.map((step, index) => {
                    const currentIdx = getCurrentStepIndex(trackingData.currentStatus);
                    const isCompleted = index < currentIdx;
                    const isCurrent = index === currentIdx;
                    const isPending = index > currentIdx;

                    return (
                      <div key={step} className={`relative flex items-start gap-4 ${isPending ? 'opacity-50' : ''}`}>
                        <div className={`absolute -left-2 z-10 flex h-5 w-5 items-center justify-center rounded-full ring-4 ring-card ${
                          isCompleted ? 'bg-primary' : isCurrent ? 'bg-blue-500 animate-pulse' : 'bg-muted border-2 border-muted-foreground'
                        }`}>
                          {isCompleted && <CheckCircle2 className="h-3 w-3 text-white" />}
                        </div>
                        <div className="pl-4">
                          <h4 className={`font-semibold ${isCurrent ? 'text-primary text-lg' : ''}`}>{step}</h4>
                          {isCurrent && trackingData.technicianNotes && (
                            <div className="mt-2 rounded-lg bg-muted p-3 text-sm">
                              <span className="font-medium block mb-1">Technician Note:</span>
                              {trackingData.technicianNotes}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </motion.div>
          )}

        </div>
      </main>

      <FloatingContact />
      <Footer />
    </div>
  );
}
