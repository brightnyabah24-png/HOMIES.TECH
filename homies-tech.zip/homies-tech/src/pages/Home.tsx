import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { FloatingContact } from "@/components/layout/FloatingContact";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { ShieldCheck, Wrench, Clock, Home as HomeIcon, Smartphone, Laptop, ShoppingBag, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useListReviews } from "@workspace/api-client-react";
import { getListReviewsQueryKey } from "@workspace/api-client-react";

export default function Home() {
  const { data: reviews } = useListReviews(
    { featured: true },
    { query: { queryKey: getListReviewsQueryKey({ featured: true }) } }
  );

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative flex min-h-[80vh] items-center justify-center overflow-hidden bg-background">
          <div className="absolute inset-0 z-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-primary/20 via-background to-background"></div>
          
          <div className="container relative z-10 mx-auto px-4 py-20 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="mx-auto mb-8 dark:bg-transparent bg-foreground p-4 rounded-[24px] inline-block"
            >
              <img src="/logo.png" alt="Homies Tech Logo" className="h-24 md:h-32 object-contain" />
            </motion.div>
            
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="mb-6 font-display text-4xl font-bold tracking-tight sm:text-5xl md:text-7xl lg:text-8xl"
            >
              Tamale's #1 Tech <br/>
              <span className="text-primary">Repair & Accessories Hub</span>
            </motion.h1>
            
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="mx-auto mb-10 max-w-2xl text-lg text-muted-foreground md:text-xl"
            >
              Premium service, certified technicians, and genuine parts. We bring life back to your devices with speed and precision.
            </motion.p>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex flex-col items-center justify-center gap-4 sm:flex-row"
            >
              <Link href="/booking" className="w-full sm:w-auto">
                <Button size="lg" className="w-full rounded-full text-base h-14 px-8">Book a Repair</Button>
              </Link>
              <Link href="/shop" className="w-full sm:w-auto">
                <Button size="lg" variant="outline" className="w-full rounded-full text-base h-14 px-8">Shop Now</Button>
              </Link>
              <Link href="/tracking" className="w-full sm:w-auto">
                <Button size="lg" variant="secondary" className="w-full rounded-full text-base h-14 px-8">Track Device</Button>
              </Link>
            </motion.div>
          </div>
        </section>

        {/* Trust Badges */}
        <section className="border-y bg-card py-8">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-2 gap-4 md:grid-cols-5">
              <div className="flex flex-col items-center text-center gap-2">
                <Clock className="h-8 w-8 text-primary" />
                <span className="text-sm font-medium">Same-Day Repairs</span>
              </div>
              <div className="flex flex-col items-center text-center gap-2">
                <ShieldCheck className="h-8 w-8 text-primary" />
                <span className="text-sm font-medium">Certified Technicians</span>
              </div>
              <div className="flex flex-col items-center text-center gap-2">
                <Wrench className="h-8 w-8 text-primary" />
                <span className="text-sm font-medium">Affordable Pricing</span>
              </div>
              <div className="flex flex-col items-center text-center gap-2">
                <HomeIcon className="h-8 w-8 text-primary" />
                <span className="text-sm font-medium">Home Service</span>
              </div>
              <div className="col-span-2 flex flex-col items-center text-center gap-2 md:col-span-1">
                <ShieldCheck className="h-8 w-8 text-primary" />
                <span className="text-sm font-medium">3-Day Warranty</span>
              </div>
            </div>
          </div>
        </section>

        {/* Services Overview */}
        <section className="py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="mb-16 text-center">
              <h2 className="font-display text-3xl font-bold md:text-5xl">Our Services</h2>
              <p className="mt-4 text-muted-foreground text-lg">Everything you need to stay connected.</p>
            </div>
            
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              <Link href="/phone-repair">
                <motion.div 
                  whileHover={{ y: -5 }}
                  className="group relative h-full cursor-pointer overflow-hidden rounded-3xl border bg-card p-8 transition-shadow hover:shadow-xl"
                >
                  <Smartphone className="mb-6 h-12 w-12 text-primary" />
                  <h3 className="mb-2 font-display text-2xl font-semibold">Phone Repair</h3>
                  <p className="text-muted-foreground">Screen replacement, battery issues, water damage, and more.</p>
                </motion.div>
              </Link>
              
              <Link href="/laptop-repair">
                <motion.div 
                  whileHover={{ y: -5 }}
                  className="group relative h-full cursor-pointer overflow-hidden rounded-3xl border bg-card p-8 transition-shadow hover:shadow-xl"
                >
                  <Laptop className="mb-6 h-12 w-12 text-primary" />
                  <h3 className="mb-2 font-display text-2xl font-semibold">Laptop Repair</h3>
                  <p className="text-muted-foreground">Hardware fixes, software troubleshooting, and upgrades.</p>
                </motion.div>
              </Link>

              <Link href="/shop">
                <motion.div 
                  whileHover={{ y: -5 }}
                  className="group relative h-full cursor-pointer overflow-hidden rounded-3xl border bg-card p-8 transition-shadow hover:shadow-xl"
                >
                  <ShoppingBag className="mb-6 h-12 w-12 text-primary" />
                  <h3 className="mb-2 font-display text-2xl font-semibold">Accessories Shop</h3>
                  <p className="text-muted-foreground">Premium cases, chargers, screen protectors, and audio gear.</p>
                </motion.div>
              </Link>

              <Link href="/tracking">
                <motion.div 
                  whileHover={{ y: -5 }}
                  className="group relative h-full cursor-pointer overflow-hidden rounded-3xl border bg-card p-8 transition-shadow hover:shadow-xl"
                >
                  <Search className="mb-6 h-12 w-12 text-primary" />
                  <h3 className="mb-2 font-display text-2xl font-semibold">Device Tracking</h3>
                  <p className="text-muted-foreground">Track the exact status of your repair in real-time.</p>
                </motion.div>
              </Link>
            </div>
          </div>
        </section>

        {/* Featured Reviews */}
        <section className="py-24 bg-card border-t">
          <div className="container mx-auto px-4">
            <div className="mb-16 text-center">
              <h2 className="font-display text-3xl font-bold md:text-5xl">What Our Customers Say</h2>
              <p className="mt-4 text-muted-foreground text-lg">Trusted by the community.</p>
            </div>
            
            {reviews && reviews.length > 0 ? (
              <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
                {reviews.slice(0, 3).map((review) => (
                  <div key={review.id} className="rounded-3xl border bg-background p-8">
                    <div className="mb-4 flex">
                      {[...Array(5)].map((_, i) => (
                        <svg
                          key={i}
                          className={`h-5 w-5 ${i < review.rating ? "text-yellow-400" : "text-gray-300"}`}
                          fill="currentColor"
                          viewBox="0 0 20 20"
                        >
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                      ))}
                    </div>
                    <p className="mb-6 text-muted-foreground italic">"{review.comment}"</p>
                    <div className="font-medium">{review.name}</div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center text-muted-foreground">No reviews yet.</div>
            )}
            
            <div className="mt-12 text-center">
              <Link href="/reviews">
                <Button variant="outline" className="rounded-full">Read All Reviews</Button>
              </Link>
            </div>
          </div>
        </section>
      </main>

      <FloatingContact />
      <Footer />
    </div>
  );
}
