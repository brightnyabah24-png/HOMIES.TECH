import { useState, useRef, useEffect } from "react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { useListTracking, useUpdateTracking, getListTrackingQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

const STEPS = [
  "Received",
  "Under Diagnosis",
  "Awaiting Parts",
  "Repair In Progress",
  "Quality Check",
  "Ready for Pickup",
  "Delivered"
];

export default function AdminTracking() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: trackings, isLoading } = useListTracking({ query: { queryKey: getListTrackingQueryKey() } });

  const updateTracking = useUpdateTracking({
    mutation: {
      onSuccess: () => {
        toast({ title: "Tracking updated" });
        queryClient.invalidateQueries({ queryKey: getListTrackingQueryKey() });
      }
    }
  });

  const handleStatusChange = (id: number, currentStatus: string) => {
    updateTracking.mutate({ id, data: { currentStatus } });
  };

  const handleNotesChange = (id: number, technicianNotes: string, currentStatus: string) => {
    updateTracking.mutate({ id, data: { currentStatus, technicianNotes } });
  };

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold font-display">Tracking Management</h1>
        <p className="text-muted-foreground text-sm">Update the live tracking status for customer devices.</p>
      </div>

      <div className="border rounded-lg bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[120px]">Tracking ID</TableHead>
              <TableHead className="w-[200px]">Device & Customer</TableHead>
              <TableHead className="w-[250px]">Current Status</TableHead>
              <TableHead>Technician Notes</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array(5).fill(0).map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                  <TableCell><Skeleton className="h-8 w-32" /></TableCell>
                  <TableCell><Skeleton className="h-10 w-full" /></TableCell>
                  <TableCell><Skeleton className="h-10 w-full" /></TableCell>
                </TableRow>
              ))
            ) : trackings && trackings.length > 0 ? (
              trackings.map((tracking) => (
                <TableRow key={tracking.id}>
                  <TableCell className="font-mono font-medium text-primary align-top pt-4">
                    {tracking.trackingId}
                  </TableCell>
                  <TableCell className="align-top pt-4">
                    <div className="font-medium text-sm">{tracking.deviceType} - {tracking.brand}</div>
                    <div className="text-xs text-muted-foreground mt-1">{tracking.customerName}</div>
                    <div className="text-xs text-muted-foreground">{tracking.customerPhone}</div>
                  </TableCell>
                  <TableCell className="align-top pt-4">
                    <Select 
                      value={tracking.currentStatus} 
                      onValueChange={(val) => handleStatusChange(tracking.id, val)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {STEPS.map(step => (
                          <SelectItem key={step} value={step}>{step}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {tracking.updatedAt && (
                      <div className="text-[10px] text-muted-foreground mt-2 text-right">
                        Last updated: {format(new Date(tracking.updatedAt), "MMM d, h:mm a")}
                      </div>
                    )}
                  </TableCell>
                  <TableCell className="align-top pt-4">
                    <NoteEditor 
                      initialNote={tracking.technicianNotes || ""} 
                      onSave={(note) => handleNotesChange(tracking.id, note, tracking.currentStatus)} 
                    />
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                  No tracking records found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </AdminLayout>
  );
}

// Separate component for debounced note saving
function NoteEditor({ initialNote, onSave }: { initialNote: string, onSave: (note: string) => void }) {
  const [note, setNote] = useState(initialNote);
  const initialRef = useRef(initialNote);

  // When initialNote changes from server (e.g. after save), update if we aren't editing
  useEffect(() => {
    if (initialNote !== initialRef.current) {
      setNote(initialNote);
      initialRef.current = initialNote;
    }
  }, [initialNote]);

  const handleBlur = () => {
    if (note !== initialRef.current) {
      onSave(note);
      initialRef.current = note;
    }
  };

  return (
    <Textarea
      value={note}
      onChange={(e) => setNote(e.target.value)}
      onBlur={handleBlur}
      placeholder="Add notes for the customer..."
      className="min-h-[80px] resize-none text-sm"
    />
  );
}
