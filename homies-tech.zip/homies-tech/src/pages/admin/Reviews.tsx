import { AdminLayout } from "@/components/admin/AdminLayout";
import { useListAllReviews, useUpdateReview, useDeleteReview, getListAllReviewsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Star, CheckCircle, Trash2, StarHalf } from "lucide-react";

export default function AdminReviews() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: reviews, isLoading } = useListAllReviews({ query: { queryKey: getListAllReviewsQueryKey() } });

  const updateReview = useUpdateReview({
    mutation: {
      onSuccess: () => {
        toast({ title: "Review updated" });
        queryClient.invalidateQueries({ queryKey: getListAllReviewsQueryKey() });
      }
    }
  });

  const deleteReview = useDeleteReview({
    mutation: {
      onSuccess: () => {
        toast({ title: "Review deleted" });
        queryClient.invalidateQueries({ queryKey: getListAllReviewsQueryKey() });
      }
    }
  });

  const handleApprove = (id: number) => {
    updateReview.mutate({ id, data: { status: "approved" } });
  };

  const handleToggleFeatured = (id: number, currentFeatured: boolean) => {
    updateReview.mutate({ id, data: { featured: !currentFeatured } });
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this review?")) {
      deleteReview.mutate({ id });
    }
  };

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold font-display">Reviews Management</h1>
        <p className="text-muted-foreground text-sm">Approve and feature customer reviews.</p>
      </div>

      <div className="border rounded-lg bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Customer</TableHead>
              <TableHead>Rating</TableHead>
              <TableHead className="w-1/2">Comment</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array(5).fill(0).map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-full" /></TableCell>
                  <TableCell><Skeleton className="h-6 w-16 rounded-full" /></TableCell>
                  <TableCell className="text-right"><Skeleton className="h-8 w-24 ml-auto" /></TableCell>
                </TableRow>
              ))
            ) : reviews && reviews.length > 0 ? (
              reviews.map((review) => (
                <TableRow key={review.id} className={review.status === 'pending' ? 'bg-muted/30' : ''}>
                  <TableCell className="font-medium">{review.name}</TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <span className="font-bold mr-1">{review.rating}</span>
                      <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                    </div>
                  </TableCell>
                  <TableCell>
                    <p className="text-sm line-clamp-2" title={review.comment}>{review.comment}</p>
                  </TableCell>
                  <TableCell>
                    {review.status === 'pending' ? (
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400">
                        Pending
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">
                        Approved
                      </span>
                    )}
                    {review.featured && (
                      <span className="ml-2 inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400">
                        Featured
                      </span>
                    )}
                  </TableCell>
                  <TableCell className="text-right space-x-2">
                    {review.status === 'pending' && (
                      <Button variant="outline" size="sm" className="text-green-600 border-green-200 hover:bg-green-50" onClick={() => handleApprove(review.id)}>
                        <CheckCircle className="h-4 w-4 mr-1" /> Approve
                      </Button>
                    )}
                    {review.status === 'approved' && (
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className={review.featured ? "text-purple-600 border-purple-200" : ""}
                        onClick={() => handleToggleFeatured(review.id, review.featured || false)}
                      >
                        <StarHalf className="h-4 w-4 mr-1" /> 
                        {review.featured ? "Unfeature" : "Feature"}
                      </Button>
                    )}
                    <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive" onClick={() => handleDelete(review.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                  No reviews found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </AdminLayout>
  );
}
