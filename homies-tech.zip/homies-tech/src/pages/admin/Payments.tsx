import { AdminLayout } from "@/components/admin/AdminLayout";
import {
  useListPayments,
  useGetRevenueStats,
  useRefundPayment,
  useExportPayments,
  getListPaymentsQueryKey,
  getGetRevenueStatsQueryKey,
  getExportPaymentsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { Download, RefreshCcw, DollarSign } from "lucide-react";

export default function AdminPayments() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: payments, isLoading: loadingPayments } = useListPayments(
    {},
    { query: { queryKey: getListPaymentsQueryKey({}) } },
  );
  const { data: stats, isLoading: loadingStats } = useGetRevenueStats({
    query: { queryKey: getGetRevenueStatsQueryKey() },
  });

  const refundPayment = useRefundPayment({
    mutation: {
      onSuccess: () => {
        toast({ title: "Refund initiated" });
        queryClient.invalidateQueries({
          queryKey: getListPaymentsQueryKey({}),
        });
        queryClient.invalidateQueries({
          queryKey: getGetRevenueStatsQueryKey(),
        });
      },
      onError: () => {
        toast({ title: "Refund failed", variant: "destructive" });
      },
    },
  });

  const { data: exportData, refetch: fetchExport } = useExportPayments({
    query: { enabled: false, queryKey: getExportPaymentsQueryKey() },
  });

  const handleExport = async () => {
    const result = await fetchExport();
    const csv = result.data;
    if (!csv) return;
    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.setAttribute("hidden", "");
    a.setAttribute("href", url);
    a.setAttribute(
      "download",
      `payments_export_${format(new Date(), "yyyyMMdd")}.csv`,
    );
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    toast({ title: "Export successful" });
  };

  const handleRefund = (id: number) => {
    if (confirm("Are you sure you want to refund this payment?")) {
      refundPayment.mutate({ id } as { id: number });
    }
  };

  const statusColors: Record<string, string> = {
    success:
      "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
    pending:
      "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
    failed: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
    refunded: "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300",
  };

  return (
    <AdminLayout>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold font-display">
            Payments & Revenue
          </h1>
          <p className="text-muted-foreground text-sm">
            Monitor transactions and financial performance.
          </p>
        </div>
        <Button variant="outline" onClick={handleExport}>
          <Download className="h-4 w-4 mr-2" />
          Export CSV
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Revenue
            </CardTitle>
            <DollarSign className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            {loadingStats ? (
              <Skeleton className="h-7 w-24" />
            ) : (
              <div className="text-2xl font-bold">
                GH₵ {stats?.totalRevenue || 0}
              </div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Successful
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loadingStats ? (
              <Skeleton className="h-7 w-12" />
            ) : (
              <div className="text-2xl font-bold text-green-600">
                {stats?.successfulPayments || 0}
              </div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Pending
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loadingStats ? (
              <Skeleton className="h-7 w-12" />
            ) : (
              <div className="text-2xl font-bold text-yellow-600">
                {stats?.pendingPayments || 0}
              </div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Failed
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loadingStats ? (
              <Skeleton className="h-7 w-12" />
            ) : (
              <div className="text-2xl font-bold text-destructive">
                {stats?.failedPayments || 0}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="border rounded-lg bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Reference</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Network</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loadingPayments ? (
              Array(5)
                .fill(0)
                .map((_, i) => (
                  <TableRow key={i}>
                    <TableCell>
                      <Skeleton className="h-4 w-24" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-4 w-20" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-4 w-32" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-4 w-16" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-4 w-16" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-20 rounded-full" />
                    </TableCell>
                    <TableCell className="text-right">
                      <Skeleton className="h-8 w-8 ml-auto" />
                    </TableCell>
                  </TableRow>
                ))
            ) : payments && payments.length > 0 ? (
              payments.map((payment) => (
                <TableRow key={payment.id}>
                  <TableCell className="font-mono text-xs text-muted-foreground">
                    {payment.reference}
                  </TableCell>
                  <TableCell className="text-sm">
                    {format(new Date(payment.createdAt), "MMM d, yyyy HH:mm")}
                  </TableCell>
                  <TableCell className="text-sm">
                    {payment.customerPhone ||
                      payment.customerEmail ||
                      "Unknown"}
                  </TableCell>
                  <TableCell className="uppercase text-sm">
                    {payment.network || "Card"}
                  </TableCell>
                  <TableCell className="font-bold">
                    GH₵ {payment.amount}
                  </TableCell>
                  <TableCell>
                    <span
                      className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium uppercase ${statusColors[payment.status] || ""}`}
                    >
                      {payment.status}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    {payment.status === "success" && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRefund(payment.id)}
                        title="Refund Payment"
                      >
                        <RefreshCcw className="h-4 w-4" />
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={7}
                  className="text-center py-8 text-muted-foreground"
                >
                  No payments found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </AdminLayout>
  );
}
