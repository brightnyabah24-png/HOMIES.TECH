import { useState } from "react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { useListServices, useCreateService, useUpdateService, useDeleteService, getListServicesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Edit, Trash2, Plus } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function AdminServices() {
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  
  const [formData, setFormData] = useState({
    name: "",
    deviceType: "phone",
    price: "",
    estimatedTime: "",
    description: ""
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: services, isLoading } = useListServices({}, { query: { queryKey: getListServicesQueryKey({}) } });

  const createService = useCreateService({
    mutation: {
      onSuccess: () => {
        toast({ title: "Service created" });
        setIsAddOpen(false);
        resetForm();
        queryClient.invalidateQueries({ queryKey: getListServicesQueryKey({}) });
      }
    }
  });

  const updateService = useUpdateService({
    mutation: {
      onSuccess: () => {
        toast({ title: "Service updated" });
        setEditingId(null);
        resetForm();
        queryClient.invalidateQueries({ queryKey: getListServicesQueryKey({}) });
      }
    }
  });

  const deleteService = useDeleteService({
    mutation: {
      onSuccess: () => {
        toast({ title: "Service deleted" });
        queryClient.invalidateQueries({ queryKey: getListServicesQueryKey({}) });
      }
    }
  });

  const resetForm = () => {
    setFormData({ name: "", deviceType: "phone", price: "", estimatedTime: "", description: "" });
  };

  const handleEditClick = (s: any) => {
    setFormData({
      name: s.name,
      deviceType: s.deviceType,
      price: s.price ? s.price.toString() : "",
      estimatedTime: s.estimatedTime,
      description: s.description || ""
    });
    setEditingId(s.id);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      ...formData,
      price: formData.price ? Number(formData.price) : undefined
    };

    if (editingId) {
      updateService.mutate({ id: editingId, data: payload });
    } else {
      createService.mutate({ data: payload });
    }
  };

  return (
    <AdminLayout>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold font-display">Repair Services</h1>
          <p className="text-muted-foreground text-sm">Manage available repair services and pricing.</p>
        </div>
        
        <Dialog open={isAddOpen || editingId !== null} onOpenChange={(open) => {
          if (!open) {
            setIsAddOpen(false);
            setEditingId(null);
            resetForm();
          } else {
            setIsAddOpen(true);
          }
        }}>
          <DialogTrigger asChild>
            <Button><Plus className="h-4 w-4 mr-2" /> Add Service</Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>{editingId ? "Edit Service" : "Add Service"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label htmlFor="name">Service Name</Label>
                <Input id="name" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} required />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Device Type</Label>
                  <Select value={formData.deviceType} onValueChange={(val) => setFormData({...formData, deviceType: val})}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="phone">Phone</SelectItem>
                      <SelectItem value="laptop">Laptop</SelectItem>
                      <SelectItem value="tablet">Tablet</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="price">Price (GHS) - Empty for "Quote"</Label>
                  <Input id="price" type="number" step="0.01" value={formData.price} onChange={(e) => setFormData({...formData, price: e.target.value})} />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="estimatedTime">Estimated Time (e.g. 2-3 Hours)</Label>
                <Input id="estimatedTime" value={formData.estimatedTime} onChange={(e) => setFormData({...formData, estimatedTime: e.target.value})} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description (Optional)</Label>
                <Textarea id="description" value={formData.description} onChange={(e) => setFormData({...formData, description: e.target.value})} />
              </div>
              <Button type="submit" className="w-full" disabled={createService.isPending || updateService.isPending}>
                Save Service
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="border rounded-lg bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Service Name</TableHead>
              <TableHead>Device Type</TableHead>
              <TableHead>Est. Time</TableHead>
              <TableHead>Price</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array(5).fill(0).map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-4 w-40" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                  <TableCell className="text-right"><Skeleton className="h-8 w-16 ml-auto" /></TableCell>
                </TableRow>
              ))
            ) : services && services.length > 0 ? (
              services.map((service) => (
                <TableRow key={service.id}>
                  <TableCell className="font-medium">{service.name}</TableCell>
                  <TableCell className="capitalize">{service.deviceType}</TableCell>
                  <TableCell>{service.estimatedTime}</TableCell>
                  <TableCell>{service.price ? `GH₵ ${service.price}` : <span className="text-muted-foreground italic">Quote</span>}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => handleEditClick(service)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive" onClick={() => {
                      if (confirm("Are you sure you want to delete this service?")) {
                        deleteService.mutate({ id: service.id });
                      }
                    }}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                  No services found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </AdminLayout>
  );
}
