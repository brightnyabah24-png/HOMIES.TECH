import { useState } from "react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { useListBookings, useUpdateBooking, getListBookingsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

export default function AdminBookings() {
  const [selectedBooking, setSelectedBooking] = useState<any | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: bookings, isLoading } = useListBookings({}, { query: { queryKey: getListBookingsQueryKey({}) } });

  const updateBooking = useUpdateBooking({
    mutation: {
      onSuccess: () => {
        toast({ title: "Booking status updated" });
        queryClient.invalidateQueries({ queryKey: getListBookingsQueryKey({}) });
      }
    }
  });

  const handleStatusChange = (id: number, status: string) => {
    updateBooking.mutate({ id, data: { status } });
  };

  const statusColors: Record<string, string> = {
    "Pending": "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
    "Confirmed": "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
    "In Progress": "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
    "Completed": "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
    "Cancelled": "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400"
  };

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold font-display">Bookings</h1>
        <p className="text-muted-foreground text-sm">Manage repair appointments and requests.</p>
      </div>

      <div className="border rounded-lg bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Tracking ID</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Device</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array(5).fill(0).map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-8 w-28" /></TableCell>
                </TableRow>
              ))
            ) : bookings && bookings.length > 0 ? (
              bookings.map((booking) => (
                <TableRow key={booking.id} className="cursor-pointer hover:bg-muted/50" onClick={(e) => {
                  // Don't open sheet if clicking on select
                  if ((e.target as HTMLElement).closest('.select-trigger')) return;
                  setSelectedBooking(booking);
                }}>
                  <TableCell className="font-mono text-primary">{booking.trackingId}</TableCell>
                  <TableCell>
                    <div className="font-medium">{booking.fullName}</div>
                    <div className="text-xs text-muted-foreground">{booking.phone}</div>
                  </TableCell>
                  <TableCell>
                    <div className="capitalize">{booking.deviceType}</div>
                    <div className="text-xs text-muted-foreground">{booking.brand}</div>
                  </TableCell>
                  <TableCell>{format(new Date(booking.createdAt), "MMM d, yyyy")}</TableCell>
                  <TableCell>
                    <div className="select-trigger w-32">
                      <Select 
                        value={booking.status} 
                        onValueChange={(val) => handleStatusChange(booking.id, val)}
                        disabled={updateBooking.isPending}
                      >
                        <SelectTrigger className={`h-8 ${statusColors[booking.status] || ''}`}>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Pending">Pending</SelectItem>
                          <SelectItem value="Confirmed">Confirmed</SelectItem>
                          <SelectItem value="In Progress">In Progress</SelectItem>
                          <SelectItem value="Completed">Completed</SelectItem>
                          <SelectItem value="Cancelled">Cancelled</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                  No bookings found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <Sheet open={!!selectedBooking} onOpenChange={(o) => !o && setSelectedBooking(null)}>
        <SheetContent className="sm:max-w-md overflow-y-auto">
          <SheetHeader className="mb-6">
            <SheetTitle>Booking Details</SheetTitle>
          </SheetHeader>
          
          {selectedBooking && (
            <div className="space-y-6">
              <div className="flex items-center justify-between p-4 bg-muted rounded-xl">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Tracking ID</p>
                  <p className="text-lg font-mono font-bold text-primary">{selectedBooking.trackingId}</p>
                </div>
                <div className={`text-sm font-medium px-3 py-1 rounded-full ${statusColors[selectedBooking.status] || ''}`}>
                  {selectedBooking.status}
                </div>
              </div>

              <div>
                <h4 className="font-semibold border-b pb-2 mb-3">Customer Information</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Name</p>
                    <p className="font-medium">{selectedBooking.fullName}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Phone</p>
                    <p className="font-medium">{selectedBooking.phone}</p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-muted-foreground">Email</p>
                    <p className="font-medium">{selectedBooking.email || "N/A"}</p>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-semibold border-b pb-2 mb-3">Device & Issue</h4>
                <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                  <div>
                    <p className="text-muted-foreground">Device Type</p>
                    <p className="font-medium capitalize">{selectedBooking.deviceType}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Brand/Model</p>
                    <p className="font-medium">{selectedBooking.brand}</p>
                  </div>
                </div>
                <div className="text-sm">
                  <p className="text-muted-foreground">Problem Description</p>
                  <p className="bg-background border rounded-lg p-3 mt-1 whitespace-pre-wrap">{selectedBooking.problemDescription}</p>
                </div>
              </div>

              <div>
                <h4 className="font-semibold border-b pb-2 mb-3">Service Preferences</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Service Type</p>
                    <p className="font-medium">{selectedBooking.serviceType}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Preferred Date</p>
                    <p className="font-medium">{selectedBooking.preferredDate}</p>
                  </div>
                  {selectedBooking.preferredTime && (
                    <div>
                      <p className="text-muted-foreground">Preferred Time</p>
                      <p className="font-medium">{selectedBooking.preferredTime}</p>
                    </div>
                  )}
                  {selectedBooking.depositPaid && (
                    <div className="col-span-2 bg-green-500/10 text-green-600 p-3 rounded-lg flex items-center">
                      <span className="font-medium mr-2">Deposit Paid:</span> 
                      GH₵ {selectedBooking.depositAmount}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </AdminLayout>
  );
}
