import { useState, useMemo } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { FloatingContact } from "@/components/layout/FloatingContact";
import { useListProducts, getListProductsQueryKey, useListProductCategories, getListProductCategoriesQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Search, ShoppingCart, Trash2, Plus, Minus, ShoppingBag } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Shop() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<string>("All");
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [cart, setCart] = useState<any[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("ht_cart") || "[]");
    } catch {
      return [];
    }
  });

  const { data: products, isLoading: loadingProducts } = useListProducts(
    {},
    { query: { queryKey: getListProductsQueryKey() } }
  );

  const { data: categories } = useListProductCategories(
    { query: { queryKey: getListProductCategoriesQueryKey() } }
  );

  const filteredProducts = useMemo(() => {
    if (!products) return [];
    return products.filter((p) => {
      const matchSearch = p.name.toLowerCase().includes(search.toLowerCase());
      const matchCat = category === "All" || p.category === category;
      return matchSearch && matchCat;
    });
  }, [products, search, category]);

  const updateCart = (newCart: any[]) => {
    setCart(newCart);
    localStorage.setItem("ht_cart", JSON.stringify(newCart));
    window.dispatchEvent(new Event("cartUpdated"));
  };

  const addToCart = (product: any) => {
    const existing = cart.find((item) => item.id === product.id);
    if (existing) {
      updateCart(cart.map((item) => item.id === product.id ? { ...item, qty: item.qty + 1 } : item));
    } else {
      updateCart([...cart, { ...product, qty: 1 }]);
    }
    setIsCartOpen(true);
  };

  const removeFromCart = (id: number) => {
    updateCart(cart.filter((item) => item.id !== id));
  };

  const updateQty = (id: number, delta: number) => {
    updateCart(cart.map((item) => {
      if (item.id === id) {
        const newQty = Math.max(1, item.qty + delta);
        return { ...item, qty: newQty };
      }
      return item;
    }));
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  const handleWhatsAppOrder = () => {
    if (cart.length === 0) return;
    let message = "Hello Homies Tech! I would like to order the following items from your shop:\n\n";
    cart.forEach((item) => {
      message += `- ${item.name} (${item.qty}x) = GH₵ ${item.price * item.qty}\n`;
    });
    message += `\n*Total: GH₵ ${cartTotal}*\n\nPlease let me know how to proceed with payment and delivery.`;
    window.open(`https://wa.me/233552929516?text=${encodeURIComponent(message)}`, "_blank");
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      
      <main className="flex-1 bg-background">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-8">
            <h1 className="font-display text-3xl font-bold">Accessories Shop</h1>
            
            <div className="flex items-center gap-4 w-full md:w-auto">
              <div className="relative flex-1 md:w-80">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="Search products..." 
                  className="pl-9 rounded-full"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
              
              <Sheet open={isCartOpen} onOpenChange={setIsCartOpen}>
                <SheetTrigger asChild>
                  <Button variant="outline" size="icon" className="relative rounded-full">
                    <ShoppingCart className="h-5 w-5" />
                    {cart.length > 0 && (
                      <span className="absolute -right-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                        {cart.length}
                      </span>
                    )}
                  </Button>
                </SheetTrigger>
                <SheetContent className="w-full sm:max-w-md flex flex-col">
                  <SheetHeader>
                    <SheetTitle>Your Cart</SheetTitle>
                  </SheetHeader>
                  
                  <div className="flex-1 overflow-y-auto py-4">
                    {cart.length === 0 ? (
                      <div className="text-center text-muted-foreground pt-10">Your cart is empty.</div>
                    ) : (
                      <div className="space-y-4">
                        {cart.map((item) => (
                          <div key={item.id} className="flex gap-4 border-b pb-4">
                            <div className="h-16 w-16 bg-muted rounded-md flex-shrink-0 flex items-center justify-center overflow-hidden">
                              {item.imageUrl ? <img src={item.imageUrl} alt={item.name} className="object-cover h-full w-full" /> : <ShoppingBag className="h-6 w-6 text-muted-foreground" />}
                            </div>
                            <div className="flex-1">
                              <h4 className="font-medium line-clamp-1">{item.name}</h4>
                              <div className="text-primary font-bold">GH₵ {item.price}</div>
                              <div className="flex items-center gap-3 mt-2">
                                <Button variant="outline" size="icon" className="h-6 w-6 rounded-full" onClick={() => updateQty(item.id, -1)}>
                                  <Minus className="h-3 w-3" />
                                </Button>
                                <span className="text-sm">{item.qty}</span>
                                <Button variant="outline" size="icon" className="h-6 w-6 rounded-full" onClick={() => updateQty(item.id, 1)}>
                                  <Plus className="h-3 w-3" />
                                </Button>
                                <Button variant="ghost" size="icon" className="h-6 w-6 ml-auto text-destructive" onClick={() => removeFromCart(item.id)}>
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  
                  {cart.length > 0 && (
                    <div className="border-t pt-4 mt-auto">
                      <div className="flex justify-between font-bold text-lg mb-4">
                        <span>Total:</span>
                        <span>GH₵ {cartTotal}</span>
                      </div>
                      <Button className="w-full bg-green-500 hover:bg-green-600 text-white h-12 text-lg rounded-full" onClick={handleWhatsAppOrder}>
                        Order via WhatsApp
                      </Button>
                    </div>
                  )}
                </SheetContent>
              </Sheet>
            </div>
          </div>

          {/* Categories */}
          <div className="mb-8 flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            <Button
              variant={category === "All" ? "default" : "outline"}
              className="rounded-full"
              onClick={() => setCategory("All")}
            >
              All
            </Button>
            {categories?.map((cat) => (
              <Button
                key={cat}
                variant={category === cat ? "default" : "outline"}
                className="rounded-full whitespace-nowrap"
                onClick={() => setCategory(cat)}
              >
                {cat}
              </Button>
            ))}
          </div>

          {/* Products Grid */}
          {loadingProducts ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {Array(8).fill(0).map((_, i) => (
                <div key={i} className="flex flex-col gap-3">
                  <Skeleton className="h-60 w-full rounded-2xl" />
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-6 w-1/2" />
                </div>
              ))}
            </div>
          ) : filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <AnimatePresence>
                {filteredProducts.map((product, i) => (
                  <motion.div
                    key={product.id}
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    transition={{ duration: 0.2 }}
                    className="group flex flex-col rounded-2xl border bg-card overflow-hidden hover:shadow-lg transition-all"
                  >
                    <div className="aspect-square bg-muted relative flex items-center justify-center overflow-hidden">
                      {product.imageUrl ? (
                        <img src={product.imageUrl} alt={product.name} className="object-cover h-full w-full group-hover:scale-105 transition-transform" />
                      ) : (
                        <ShoppingBag className="h-16 w-16 text-muted-foreground/30" />
                      )}
                      <div className="absolute top-2 right-2">
                        <Badge variant={product.inStock ? "default" : "destructive"}>
                          {product.inStock ? "In Stock" : "Out of Stock"}
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="p-5 flex flex-col flex-1">
                      <h3 className="font-semibold text-lg line-clamp-2 mb-2">{product.name}</h3>
                      <div className="font-display text-xl font-bold text-primary mb-4 mt-auto">GH₵ {product.price}</div>
                      
                      <div className="flex gap-2">
                        <Button 
                          className="flex-1" 
                          disabled={!product.inStock}
                          onClick={() => addToCart(product)}
                        >
                          Add to Cart
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          ) : (
            <div className="text-center py-20 text-muted-foreground">
              <Search className="h-12 w-12 mx-auto mb-4 opacity-20" />
              <h3 className="text-lg font-medium text-foreground">No products found</h3>
              <p>Try adjusting your search or category filter</p>
            </div>
          )}
        </div>
      </main>

      <FloatingContact />
      <Footer />
    </div>
  );
}
