import { useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { FloatingContact } from "@/components/layout/FloatingContact";
import { useCreateReview, useListReviews, getListReviewsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Star } from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";

export default function Reviews() {
  const [name, setName] = useState("");
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: reviews, isLoading } = useListReviews({}, { query: { queryKey: getListReviewsQueryKey({}) } });
  
  const createReview = useCreateReview({
    mutation: {
      onSuccess: () => {
        toast({ title: "Review submitted!", description: "It will appear after approval.", variant: "default" });
        setName("");
        setRating(5);
        setComment("");
        queryClient.invalidateQueries({ queryKey: getListReviewsQueryKey({}) });
      },
      onError: () => {
        toast({ title: "Error", description: "Failed to submit review.", variant: "destructive" });
      }
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !comment) {
      toast({ title: "Validation Error", description: "Name and comment are required.", variant: "destructive" });
      return;
    }
    createReview.mutate({ data: { name, rating, comment } });
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      
      <main className="flex-1 bg-background py-16">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="text-center mb-16">
            <h1 className="font-display text-4xl font-bold md:text-5xl">Customer Reviews</h1>
            <p className="mt-4 text-muted-foreground text-lg">See what our community has to say about our service.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            <div className="lg:col-span-1">
              <Card className="sticky top-24">
                <CardHeader>
                  <CardTitle>Leave a Review</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Your Name</Label>
                      <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Rating</Label>
                      <div className="flex gap-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            type="button"
                            onClick={() => setRating(star)}
                            className="p-1 transition-colors focus:outline-none"
                          >
                            <Star className={`h-6 w-6 ${star <= rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`} />
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="comment">Your Experience</Label>
                      <Textarea 
                        id="comment" 
                        value={comment} 
                        onChange={(e) => setComment(e.target.value)} 
                        rows={4} 
                        required 
                        placeholder="Tell us about your repair experience..."
                      />
                    </div>

                    <Button type="submit" className="w-full" disabled={createReview.isPending}>
                      {createReview.isPending ? "Submitting..." : "Submit Review"}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            <div className="lg:col-span-2 space-y-6">
              {isLoading ? (
                Array(3).fill(0).map((_, i) => (
                  <div key={i} className="h-40 bg-muted animate-pulse rounded-2xl"></div>
                ))
              ) : reviews && reviews.length > 0 ? (
                reviews.map((review, i) => (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                    key={review.id}
                    className="rounded-2xl border bg-card p-6 shadow-sm"
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <div className="font-semibold text-lg">{review.name}</div>
                        <div className="text-xs text-muted-foreground">
                          {format(new Date(review.createdAt), "MMM d, yyyy")}
                        </div>
                      </div>
                      <div className="flex">
                        {[...Array(5)].map((_, idx) => (
                          <Star key={idx} className={`h-4 w-4 ${idx < review.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`} />
                        ))}
                      </div>
                    </div>
                    <p className="text-muted-foreground">{review.comment}</p>
                  </motion.div>
                ))
              ) : (
                <div className="text-center py-20 text-muted-foreground rounded-2xl border border-dashed">
                  No reviews yet. Be the first to leave one!
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      <FloatingContact />
      <Footer />
    </div>
  );
}
