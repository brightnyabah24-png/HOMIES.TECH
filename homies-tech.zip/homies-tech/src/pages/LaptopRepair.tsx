import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { FloatingContact } from "@/components/layout/FloatingContact";
import { useListServices, getListServicesQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { SiHp, SiDell, SiLenovo, SiAsus, SiApple } from "react-icons/si";

export default function LaptopRepair() {
  const { data: services, isLoading } = useListServices(
    { deviceType: "laptop" },
    { query: { queryKey: getListServicesQueryKey({ deviceType: "laptop" }) } }
  );

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      
      <main className="flex-1">
        <section className="bg-primary/5 py-20 text-center">
          <div className="container mx-auto px-4">
            <h1 className="mb-4 font-display text-4xl font-bold md:text-6xl">Laptop Repair Services</h1>
            <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
              Hardware fixes, software troubleshooting, and upgrades for all major laptop brands.
            </p>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="mb-8 text-center font-display text-2xl font-bold">Brands We Service</h2>
            <div className="flex flex-wrap justify-center gap-6 md:gap-12">
              {[
                { name: "HP", icon: SiHp },
                { name: "Dell", icon: SiDell },
                { name: "Lenovo", icon: SiLenovo },
                { name: "Asus", icon: SiAsus },
                { name: "MacBook", icon: SiApple },
                { name: "Acer" },
              ].map((brand, i) => (
                <div key={i} className="flex flex-col items-center justify-center gap-2">
                  <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-card border shadow-sm">
                    {brand.icon ? <brand.icon className="h-8 w-8 text-foreground" /> : <span className="font-bold">{brand.name[0]}</span>}
                  </div>
                  <span className="text-sm font-medium">{brand.name}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="bg-card py-16 border-t">
          <div className="container mx-auto px-4 max-w-4xl">
            <h2 className="mb-10 text-center font-display text-3xl font-bold">Standard Pricing</h2>
            
            <div className="space-y-4">
              {isLoading ? (
                Array(5).fill(0).map((_, i) => (
                  <Skeleton key={i} className="h-24 w-full rounded-2xl" />
                ))
              ) : services?.length ? (
                services.map((service, i) => (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                    key={service.id}
                    className="flex flex-col sm:flex-row items-start sm:items-center justify-between rounded-2xl border bg-background p-6 shadow-sm"
                  >
                    <div>
                      <h3 className="font-semibold text-lg">{service.name}</h3>
                      <p className="text-sm text-muted-foreground">{service.description || "Professional repair service"}</p>
                      <div className="mt-2 text-sm text-primary font-medium">Est. Time: {service.estimatedTime}</div>
                    </div>
                    <div className="mt-4 sm:mt-0 text-right">
                      <div className="font-display text-2xl font-bold">
                        {service.price ? `GH₵ ${service.price}` : "Get Quote"}
                      </div>
                      <Link href="/booking">
                        <Button className="mt-2 w-full sm:w-auto">Book Now</Button>
                      </Link>
                    </div>
                  </motion.div>
                ))
              ) : (
                <div className="text-center text-muted-foreground p-8">No services found.</div>
              )}
            </div>
            
            <div className="mt-12 text-center">
              <Link href="/booking">
                <Button size="lg" className="rounded-full px-8">Book a Different Repair</Button>
              </Link>
            </div>
          </div>
        </section>
      </main>

      <FloatingContact />
      <Footer />
    </div>
  );
}
