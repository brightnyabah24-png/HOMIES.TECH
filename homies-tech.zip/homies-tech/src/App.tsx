import { Switch, Route, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ThemeProvider } from "next-themes";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import NotFound from "@/pages/not-found";

import Home from "@/pages/Home";
import PhoneRepair from "@/pages/PhoneRepair";
import LaptopRepair from "@/pages/LaptopRepair";
import Shop from "@/pages/Shop";
import Tracking from "@/pages/Tracking";
import Booking from "@/pages/Booking";
import Reviews from "@/pages/Reviews";
import Contact from "@/pages/Contact";

import AdminLogin from "@/pages/admin/Login";
import AdminDashboard from "@/pages/admin/Dashboard";
import AdminProducts from "@/pages/admin/Products";
import AdminServices from "@/pages/admin/Services";
import AdminBookings from "@/pages/admin/Bookings";
import AdminTracking from "@/pages/admin/Tracking";
import AdminReviews from "@/pages/admin/Reviews";
import AdminPayments from "@/pages/admin/Payments";
import AdminSettings from "@/pages/admin/Settings";

const queryClient = new QueryClient();

function ProtectedRoute({ component: Component, ...rest }: any) {
  const { token } = useAuth();
  if (!token) return <Redirect to="/admin/login" />;
  return <Route {...rest} component={Component} />;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/phone-repair" component={PhoneRepair} />
      <Route path="/laptop-repair" component={LaptopRepair} />
      <Route path="/shop" component={Shop} />
      <Route path="/tracking" component={Tracking} />
      <Route path="/booking" component={Booking} />
      <Route path="/reviews" component={Reviews} />
      <Route path="/contact" component={Contact} />

      <Route path="/admin">
        <Redirect to="/admin/dashboard" />
      </Route>
      <Route path="/admin/login" component={AdminLogin} />
      <ProtectedRoute path="/admin/dashboard" component={AdminDashboard} />
      <ProtectedRoute path="/admin/products" component={AdminProducts} />
      <ProtectedRoute path="/admin/services" component={AdminServices} />
      <ProtectedRoute path="/admin/bookings" component={AdminBookings} />
      <ProtectedRoute path="/admin/tracking" component={AdminTracking} />
      <ProtectedRoute path="/admin/reviews" component={AdminReviews} />
      <ProtectedRoute path="/admin/payments" component={AdminPayments} />
      <ProtectedRoute path="/admin/settings" component={AdminSettings} />

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false}>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <TooltipProvider>
            <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
              <Router />
            </WouterRouter>
            <Toaster />
          </TooltipProvider>
        </AuthProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
