import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { setAuthTokenGetter } from "@workspace/api-client-react";

interface AdminUser {
  id: number;
  username: string;
  requiresPasswordChange?: boolean;
}

interface AuthContextType {
  token: string | null;
  user: AdminUser | null;
  setAuth: (token: string, user: AdminUser) => void;
  clearAuth: () => void;
  getToken: () => string | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(() => localStorage.getItem("ht_admin_token"));
  const [user, setUser] = useState<AdminUser | null>(() => {
    const saved = localStorage.getItem("ht_admin_user");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return null;
      }
    }
    return null;
  });

  useEffect(() => {
    setAuthTokenGetter(() => localStorage.getItem("ht_admin_token"));
  }, []);

  const setAuth = (newToken: string, newUser: AdminUser) => {
    setToken(newToken);
    setUser(newUser);
    localStorage.setItem("ht_admin_token", newToken);
    localStorage.setItem("ht_admin_user", JSON.stringify(newUser));
  };

  const clearAuth = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem("ht_admin_token");
    localStorage.removeItem("ht_admin_user");
  };

  const getToken = () => localStorage.getItem("ht_admin_token");

  return (
    <AuthContext.Provider value={{ token, user, setAuth, clearAuth, getToken }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
